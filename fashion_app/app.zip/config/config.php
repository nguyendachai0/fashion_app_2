<?php
// config.php

define('DB_HOST', 'localhost');
define('DB_NAME', 'fashion_app');
define('DB_USER', 'root');
define('DB_PASS', '');

define('BASE_URL', '/');
