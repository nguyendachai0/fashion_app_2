<header class="header-area section-padding-lr-1 transparent-bar header-padding-tb sticky-bar sticky-white-bg">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-4">
                <div class="language-wrap">
                    <ul>
                        <li><a href="#">ENG</a></li>
                        <li><a href="#">FR</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-4">
                <div class="logo text-center">
                    <a href="index.html"><img src="<?= BASE_URL ?>assets/images/logo/logo.png" alt="logo"></a>
                </div>
            </div>
            <div class="col-4">
                <div class="header-action-wrap">
                    <div class="header-action-cart">
                        <a class="cart-active" href="#">
                            <img class="injectable" src="<?= BASE_URL ?>assets/images/icon-img/bag.svg" alt="">
                            <span class="product-count">0<?= ($_SESSION['totalItems']) ? $_SESSION['totalItems'] : '0'  ?> </span>
                        </a>
                    </div>
                    <div class="header-action-menu">
                        <a class="menu-active-button" href="#">
                            <span class="info-width-1"></span>
                            <span class="info-width-2"></span>
                            <span class="info-width-3"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- mini cart start -->
<div class="sidebar-cart-active">
    <div class="sidebar-cart-all">
        <a class="cart-close" href="#"><i class="las la-times"></i></a>
        <div class="cart-content">
            <h3>Shopping Cart</h3>
            <ul>
                <?php if (isset($_SESSION['cartDetails'])) : ?>
                    <?php foreach ($_SESSION['cartDetails'] as $item) : ?>
                        <li class="single-product-cart">
                            <div class="cart-img">
                                <a href="product-details.html"><img src="<?= BASE_URL ?>uploads/product/<?= $item['image'] ?>" alt=""></a>
                            </div>
                            <div class="cart-title">
                                <h4><a href="product-details.html"><?= $item['product_name'] ?></a></h4>
                                <span> <?= $item['quantity'] ?> x <?= $item['product_price'] ?></span>
                            </div>
                            <div class="cart-delete">
                                <a href="#"><i class="las la-trash"></i></a>
                            </div>
                        </li>
                    <?php endforeach; ?>
                <?php endif; ?>
            </ul>
            <div class="cart-total">
                <h4>Subtotal: <span><?= $_SESSION['total_price'] ?> Đ</span></h4>
            </div>
            <div class="btn-style cart-checkout-btn">
                <a class="btn btn-outline-primary" href="cart.html">View cart</a>
                <a class="btn btn-outline-primary" href="checkout.html">Checkout</a>
            </div>
        </div>
    </div>
</div>
<!-- Menu start -->
<div class="off-canvas-active">
    <a class="off-canvas-close"><i class="las la-times"></i></a>
    <div class="off-canvas-wrap">
        <div class="menu-wrap">
            <div id="menu" class="slinky-mobile-menu text-left">
                <ul>
                    <li>
                        <a href="#">HOME</a>
                        <ul>
                            <li><a href="index.html">Home version 1 </a></li>
                            <li><a href="index-2.html">Home version 2</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">PAGES</a>
                        <ul>
                            <li><a href="about-us.html">About Us</a></li>
                            <li><a href="cart.html">Cart Page</a></li>
                            <li><a href="checkout.html">Checkout</a></li>
                            <li><a href="my-account.html">My Account</a></li>
                            <li><a href="wishlist.html">Wishlist</a></li>
                            <li><a href="coming-soon.html">Coming Soon</a></li>
                            <li><a href="contact.html">Contact Us</a></li>
                            <li><a href="login-register.html">Login Register</a></li>

                        </ul>
                    </li>
                    <li>
                        <a href="#">SHOP</a>
                        <ul>
                            <li><a href="shop.html">Shop Page</a></li>
                            <li><a href="shop-collection.html">Shop Collection</a></li>
                            <li><a href="shop-fullwidth.html">Shop Fullwidth</a></li>
                            <li><a href="shop-instagram.html">Shop Instagram</a></li>
                            <li><a href="product-details.html">Product Details</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">BLOG</a>
                        <ul>
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="blog-details.html">Blog Details</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>