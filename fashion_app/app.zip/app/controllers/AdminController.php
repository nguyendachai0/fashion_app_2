<?php
// Assuming you have a ProductModel to interact with the database



class AdminController
{
    public function index()
    {
        require('../app/views/admin/index.php');
    }
    public function category()
    {
    }
}
